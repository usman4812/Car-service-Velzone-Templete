<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('job_cards', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('car_manufacture_id')->nullable();
            $table->unsignedBigInteger('sale_person_id')->nullable();
            $table->unsignedBigInteger('customer_id')->nullable();
            $table->string('job_card_no')->nullable();
            $table->string('date')->nullable();
            $table->string('name')->nullable();
            $table->string('email')->nullable();
            $table->string('phone')->nullable();
            $table->string('car_model')->nullable();
            $table->string('car_plat_no')->nullable();
            $table->string('chassis_no')->nullable();
            $table->string('manu_year')->nullable();
            $table->string('full_car')->nullable();
            $table->decimal('full_car_price')->nullable();
            $table->string('promo')->nullable();
            $table->string('remarks')->nullable();
            $table->decimal('amount', 10, 2)->nullable();
            $table->decimal('net_amount', 10, 2)->nullable();
            $table->decimal('discount_amount', 10, 2)->nullable();
            $table->decimal('discount_percent', 10, 2)->nullable();
            $table->decimal('vat_amount', 5, 2)->nullable();
            $table->decimal('total_payable', 10, 2)->nullable();
            $table->foreign('car_manufacture_id')->references('id')->on('car_manufactures');
            $table->foreign('sale_person_id')->references('id')->on('sales_people');
            $table->foreign('customer_id')->references('id')->on('customers');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('job_cards');
    }
};
