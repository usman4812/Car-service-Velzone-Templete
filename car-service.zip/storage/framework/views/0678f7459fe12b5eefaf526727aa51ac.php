<?php $__env->startSection('title', 'Job Cards'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex align-items-center">
                        <h5 class="card-title mb-0 flex-grow-1">Job Card List</h5>
                        <div>
                            <a href="<?php echo e(route('job-card.create')); ?>" class="btn btn-primary">Add Job Card</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <table id="jobCard-table" class="table table-bordered dt-responsive nowrap table-striped align-middle"
                        style="width:100%">
                        <thead>
                            <tr>
                                <th>SR No.</th>
                                <th>InVoice No.</th>
                                <th>Customer Name</th>
                                <th>Sales Rep</th>
                                <th>Sub Total</th>
                                <th>Total</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            var table = $('#jobCard-table').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('job-card.index')); ?>",
                columns: [
                    {
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'job_card_no',
                        name: 'job_card_no',
                        searchable: true
                    },
                    {
                        data: 'name',
                        name: 'customer.name', // Search in the customer relationship
                        searchable: true
                    },
                    {
                        data: 'sale_person_id',
                        name: 'salesPerson.name', // Search in the salesPerson relationship
                        searchable: true
                    },
                    {
                        data: 'amount',
                        name: 'amount',
                        searchable: false
                    },
                    {
                        data: 'total_payable',
                        name: 'total_payable',
                        searchable: false
                    },
                    {
                        data: 'date',
                        name: 'date',
                        searchable: false
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    }
                ],
                order: [],
                responsive: true,
                pageLength: 10
            });

            // Sales Person Filter Change
            $('#sale_person_filter').on('change', function() {
                table.draw();
            });

            // SweetAlert Delete Confirmation
            $(document).on('click', '.show-confirm', function(e) {
                e.preventDefault();
                let form = $(this).closest('form');
                Swal.fire({
                    title: 'Are you sure?',
                    text: "This action cannot be undone!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\car-service\resources\views/pages/job-card/index.blade.php ENDPATH**/ ?>